from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField, SelectField
from wtforms.validators import DataRequired, Email, Length, EqualTo, Optional

class RegistrationForm(FlaskForm):
    name = StringField('Full Name', validators=[DataRequired(), Length(min=2)])
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired(), Length(min=6)])
    confirm = PasswordField('Confirm Password', validators=[DataRequired(), EqualTo('password')])
    role = SelectField('Role', choices=[('seeker','Job Seeker'), ('employer','Employer')], default='seeker')
    company = StringField('Company (for employers)', validators=[Optional()])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class JobForm(FlaskForm):
    title = StringField('Job Title', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired(), Length(min=10)])
    salary = StringField('Salary', validators=[Optional()])
    location = StringField('Location', validators=[Optional()])
    category = StringField('Category', validators=[Optional()])
    company = StringField('Company (optional)', validators=[Optional()])
    submit = SubmitField('Post Job')

class SearchForm(FlaskForm):
    keyword = StringField('Keyword', validators=[Optional()])
    location = StringField('Location', validators=[Optional()])
    category = StringField('Category', validators=[Optional()])
    submit = SubmitField('Search')

class ApplyForm(FlaskForm):
    cover_letter = TextAreaField('Cover Letter', validators=[Optional(), Length(max=2000)])
    submit = SubmitField('Apply')
