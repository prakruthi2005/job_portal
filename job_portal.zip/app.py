from flask import Flask, render_template, redirect, url_for, flash, request
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, Job, Application
from forms import RegistrationForm, LoginForm, JobForm, SearchForm, ApplyForm
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'devsecret123')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///app.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db.init_app(app)

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.before_first_request
def create_tables():
    db.create_all()
    # Create sample admin/employer/seeker if not exists
    if not User.query.filter_by(email='admin@example.com').first():
        admin = User(name='Admin', email='admin@example.com', role='admin')
        admin.set_password('adminpass')
        db.session.add(admin)
    if not User.query.filter_by(email='employer@example.com').first():
        emp = User(name='Employer', email='employer@example.com', role='employer', company='Acme Corp')
        emp.set_password('employerpass')
        db.session.add(emp)
    if not User.query.filter_by(email='seeker@example.com').first():
        seeker = User(name='Seeker', email='seeker@example.com', role='seeker')
        seeker.set_password('seekerpass')
        db.session.add(seeker)
    db.session.commit()

@app.route('/')
def index():
    form = SearchForm(request.args)
    q = Job.query
    if form.keyword.data:
        keyword = f"%{form.keyword.data}%"
        q = q.filter((Job.title.ilike(keyword)) | (Job.description.ilike(keyword)) | (Job.company.ilike(keyword)))
    if form.location.data:
        q = q.filter(Job.location.ilike(f"%{form.location.data}%"))
    if form.category.data:
        q = q.filter(Job.category.ilike(f"%{form.category.data}%"))
    jobs = q.order_by(Job.created_at.desc()).all()
    return render_template('index.html', jobs=jobs, form=form)

@app.route('/register', methods=['GET','POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        if User.query.filter_by(email=form.email.data).first():
            flash('Email already registered', 'warning')
            return redirect(url_for('register'))
        user = User(name=form.name.data, email=form.email.data, role=form.role.data, company=form.company.data or None)
        user.set_password(form.password.data)
        db.session.add(user)
        db.session.commit()
        flash('Registration successful. Please login.', 'success')
        return redirect(url_for('login'))
    return render_template('register.html', form=form)

@app.route('/login', methods=['GET','POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(email=form.email.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            flash('Logged in successfully.', 'success')
            return redirect(url_for('index'))
        flash('Invalid credentials', 'danger')
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Logged out', 'info')
    return redirect(url_for('index'))

@app.route('/post-job', methods=['GET','POST'])
@login_required
def post_job():
    if current_user.role != 'employer':
        flash('Only employers can post jobs', 'warning')
        return redirect(url_for('index'))
    form = JobForm()
    if form.validate_on_submit():
        job = Job(
            title=form.title.data,
            description=form.description.data,
            salary=form.salary.data,
            location=form.location.data,
            category=form.category.data,
            company=current_user.company or form.company.data,
            employer_id=current_user.id
        )
        db.session.add(job)
        db.session.commit()
        flash('Job posted successfully', 'success')
        return redirect(url_for('employer_dashboard'))
    return render_template('post_job.html', form=form)

@app.route('/job/<int:job_id>', methods=['GET','POST'])
def job_detail(job_id):
    job = Job.query.get_or_404(job_id)
    form = ApplyForm()
    applied = False
    if current_user.is_authenticated:
        applied = Application.query.filter_by(job_id=job.id, user_id=current_user.id).first() is not None
    if form.validate_on_submit():
        if not current_user.is_authenticated or current_user.role != 'seeker':
            flash('You must be logged in as a job seeker to apply', 'warning')
            return redirect(url_for('login'))
        appn = Application(job_id=job.id, user_id=current_user.id, cover_letter=form.cover_letter.data)
        db.session.add(appn)
        db.session.commit()
        flash('Application submitted', 'success')
        return redirect(url_for('job_detail', job_id=job.id))
    return render_template('job_detail.html', job=job, form=form, applied=applied)

@app.route('/employer')
@login_required
def employer_dashboard():
    if current_user.role != 'employer':
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    jobs = Job.query.filter_by(employer_id=current_user.id).order_by(Job.created_at.desc()).all()
    return render_template('employer_dashboard.html', jobs=jobs)

@app.route('/applications/<int:job_id>')
@login_required
def view_applications(job_id):
    job = Job.query.get_or_404(job_id)
    if current_user.role != 'employer' or job.employer_id != current_user.id:
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    apps = Application.query.filter_by(job_id=job.id).order_by(Application.created_at.desc()).all()
    return render_template('applications.html', apps=apps, job=job)

@app.route('/admin')
@login_required
def admin_dashboard():
    if current_user.role != 'admin':
        flash('Admins only', 'danger')
        return redirect(url_for('index'))
    users = User.query.order_by(User.id.desc()).all()
    jobs = Job.query.order_by(Job.created_at.desc()).all()
    return render_template('admin_dashboard.html', users=users, jobs=jobs)

@app.route('/delete-job/<int:job_id>', methods=['POST'])
@login_required
def delete_job(job_id):
    job = Job.query.get_or_404(job_id)
    if not ((current_user.role == 'employer' and job.employer_id == current_user.id) or current_user.role == 'admin'):
        flash('Access denied', 'danger')
        return redirect(url_for('index'))
    db.session.delete(job)
    db.session.commit()
    flash('Job deleted', 'info')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
