# Job Portal Web Application (Flask)

## Overview
A simple job portal built with Flask, SQLite, HTML/CSS and Bootstrap. Supports three roles:
- **Job Seekers**: register, search jobs, view and apply.
- **Employers**: post jobs, manage listings.
- **Admin**: view and manage users & jobs.

## Features
- User registration & login (role-based)
- Post jobs with title, description, salary, location, category
- Search jobs with filters (location, category, company)
- Apply to jobs (application saved)
- Admin dashboard to inspect users and jobs

## Setup (local)
1. Create and activate a Python virtual environment:
   ```
   python3 -m venv venv
   source venv/bin/activate    # on Windows: venv\Scripts\activate
   ```
2. Install dependencies:
   ```
   pip install -r requirements.txt
   ```
3. Initialize the database and run the app:
   ```
   python app.py
   ```
   On first run the app will create `app.db` (SQLite) and an admin user:
   - email: admin@example.com
   - password: adminpass

4. Open the site at `http://127.0.0.1:5000/`

## Files
- `app.py` - main Flask application and routes
- `models.py` - SQLAlchemy models (User, Job, Application)
- `forms.py` - WTForms definitions
- `templates/` - HTML templates (Bootstrap via CDN)
- `static/` - static assets (CSS)

## Notes & Extensibility
- To use PostgreSQL, change `SQLALCHEMY_DATABASE_URI` in `app.py`.
- You can add email notifications, file uploads for resumes, and REST API endpoints as enhancements.

## Demo users
- Admin: admin@example.com / adminpass
- Employer example: employer@example.com / employerpass
- Jobseeker example: seeker@example.com / seekerpass
